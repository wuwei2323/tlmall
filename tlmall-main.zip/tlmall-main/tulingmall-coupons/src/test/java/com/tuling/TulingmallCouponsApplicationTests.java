package com.tuling;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TulingmallCouponsApplicationTests {

	@Test
	void contextLoads() {
	}

}
